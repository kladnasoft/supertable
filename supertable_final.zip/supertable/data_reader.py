# route: supertable.data_reader

from __future__ import annotations

import math
import re
from enum import Enum
from typing import Optional, Tuple, Any, List, Dict

import pandas as pd

from supertable.config.defaults import logger
from supertable.storage.storage_factory import get_storage
from supertable.storage.storage_interface import StorageInterface
from supertable.utils.timer import Timer
from supertable.query_plan_manager import QueryPlanManager
from supertable.utils.sql_parser import SQLParser
from supertable.plan_extender import extend_execution_plan
from supertable.engine.plan_stats import PlanStats
from supertable.rbac.access_control import restrict_read_access  # noqa: F401

from supertable.engine.data_estimator import DataEstimator
from supertable.engine.executor import Executor
from supertable.engine.engine_enum import Engine as engine
from supertable.data_classes import DedupViewDef, TombstoneDef
from supertable.redis_catalog import RedisCatalog


class Status(Enum):
    OK = "ok"
    ERROR = "error"


from collections import defaultdict
from typing import List, Tuple



class DataReader:
    """
    Facade — preserves the original interface; now delegates:
      - Estimation to DataEstimator
      - Execution to Executor (DuckDB/Spark)
    """

    def __init__(self, super_name: str, organization: str, query: str):
        self.super_name = super_name
        self.organization = organization
        self.query = query

        self.storage: StorageInterface = get_storage()

        self.timer: Optional[Timer] = None
        self.plan_stats: Optional[PlanStats] = None
        self.query_plan_manager: Optional[QueryPlanManager] = None

        self._log_ctx = ""

    def _lp(self, msg: str) -> str:
        return f"{self._log_ctx}{msg}"


    def execute(
        self,
        role_name: str,
        with_scan: bool = False,
        engine: engine = engine.AUTO,
    ) -> Tuple[pd.DataFrame, Status, Optional[str]]:
        status = Status.ERROR
        message: Optional[str] = None
        self.timer = Timer()
        self.plan_stats = PlanStats()

        # Build parser with the correct dialect for the chosen engine.
        parser = SQLParser(
            super_name=self.super_name,
            query=self.query,
            dialect=engine.dialect,
        )
        tables = parser.get_table_tuples()
        physical_tables = parser.get_physical_tables()

        # RBAC check — also returns per-alias column/row filter definitions
        rbac_views = restrict_read_access(
            super_name=self.super_name,
            organization=self.organization,
            role_name=role_name,
            tables=tables,
            physical_tables=physical_tables,
        )

        try:
            # Make executor aware of storage for presign retry
            executor = Executor(storage=self.storage, organization=self.organization)

            # Initialize plan manager and query id/hash (same as before)
            self.query_plan_manager = QueryPlanManager(
                super_name=self.super_name,
                organization=self.organization,
                current_meta_path="redis://meta/root",
                query=parser.original_query,
            )
            self._log_ctx = f"[qid={self.query_plan_manager.query_id} qh={self.query_plan_manager.query_hash}] "

            # 1) ESTIMATE
            estimator = DataEstimator(
                organization=self.organization,
                storage=self.storage,
                tables=tables
            )
            reflection = estimator.estimate()

            logger.info(self._lp(f"[estimate] storage={reflection.storage_type} | files={reflection.total_reflections} | bytes={reflection.reflection_bytes}"))

            # Wire RBAC column/row filter definitions onto the reflection so
            # executors create filtered views for restricted roles.
            reflection.rbac_views = rbac_views

            # --- Dedup-on-read & tombstones: look up table configs and snapshot metadata ---
            try:
                catalog = RedisCatalog()
                for td in tables:
                    tbl_cfg = catalog.get_table_config(
                        self.organization, td.super_name, td.simple_name,
                    )
                    if tbl_cfg and tbl_cfg.get("dedup_on_read"):
                        pk = tbl_cfg.get("primary_keys", [])
                        if pk:
                            # visible_columns: what the user actually asked for.
                            # Empty list (SELECT *) means "all user columns" — the
                            # executor will expose everything except __rn__.
                            reflection.dedup_views[td.alias] = DedupViewDef(
                                primary_keys=pk,
                                order_column="__timestamp__",
                                visible_columns=list(td.columns or []),
                            )

                    # Tombstone filtering: read from snapshot payload in Redis leaf
                    try:
                        leaf = catalog.get_leaf(
                            self.organization, td.super_name, td.simple_name,
                        )
                        payload = (leaf or {}).get("payload") if isinstance(leaf, dict) else None
                        if isinstance(payload, dict):
                            tomb_block = payload.get("tombstones")
                            if isinstance(tomb_block, dict):
                                tomb_keys = tomb_block.get("deleted_keys") or []
                                tomb_pk = tomb_block.get("primary_keys") or []
                                if tomb_keys and tomb_pk:
                                    reflection.tombstone_views[td.alias] = TombstoneDef(
                                        primary_keys=tomb_pk,
                                        deleted_keys=tomb_keys,
                                    )
                    except Exception as te:
                        logger.debug(self._lp(f"[tombstone] leaf lookup failed for {td.alias}: {te}"))

            except Exception as e:
                logger.warning(self._lp(f"[dedup] config lookup failed, skipping dedup: {e}"))

            if not reflection.supers:
                message = "No parquet files found"
                return pd.DataFrame(), status, message

            # 2) EXECUTE
            result_df, engine_used = executor.execute(
                engine=engine,
                reflection=reflection,
                parser=parser,
                query_manager=self.query_plan_manager,
                timer=self.timer,
                plan_stats=self.plan_stats,
                log_prefix=self._lp(""),
            )
            status = Status.OK
        except Exception as e:
            message = str(e)
            logger.error(self._lp(f"Exception: {e}"))
            result_df = pd.DataFrame()

        # Extend plan + timings
        self.timer.capture_and_reset_timing(event="EXECUTING_QUERY")
        try:
            extend_execution_plan(
                query_plan_manager=self.query_plan_manager,
                role_name=role_name,
                timing=self.timer.timings,
                plan_stats=self.plan_stats,
                status=str(status.value),
                message=message,
                result_shape=result_df.shape,
            )
        except Exception as e:
            logger.error(self._lp(f"extend_execution_plan exception: {e}"))

        self.timer.capture_and_reset_timing(event="EXTENDING_PLAN")
        self.timer.capture_duration(event="TOTAL_EXECUTE")
        return result_df, status, message

def _ensure_sql_limit(sql: str, default_limit: int) -> str:
    """
    If the outermost query has no LIMIT clause, append one.

    Only appends when the SQL does not already end with a LIMIT (ignoring
    trailing whitespace/semicolons).  This avoids breaking queries that
    already specify their own LIMIT, subqueries that contain LIMIT internally,
    or CTEs.
    """
    # Strip trailing whitespace and optional semicolons for inspection
    stripped = sql.rstrip().rstrip(";").rstrip()

    # Check if the query already ends with LIMIT <number> (possibly with OFFSET)
    # Pattern: LIMIT <digits> [OFFSET <digits>] at the very end
    if re.search(r'\bLIMIT\s+\d+\s*(?:OFFSET\s+\d+\s*)?$', stripped, re.IGNORECASE):
        return sql

    return f"{sql}\nLIMIT {int(default_limit)}"


def query_sql(
        organization: str,
        super_name: str,
        sql: str,
        limit: int,
        engine: Any,
        role_name: str,
) -> Tuple[List[str], List[List[Any]], List[Dict[str, Any]]]:
    """
    Execute SQL query and return results in the format expected by MCP server.
    Returns: (columns, rows, columns_meta)
    """
    # Safety guard: ensure a LIMIT is present so unbounded queries don't
    # overwhelm the MCP response payload.
    sql = _ensure_sql_limit(sql, default_limit=limit)

    reader = DataReader(organization=organization, super_name=super_name, query=sql)

    # Execute the query
    result_df, status, message = reader.execute(
        role_name=role_name,
        engine=engine,
        with_scan=False,
    )

    if status == Status.ERROR:
        raise RuntimeError(f"Query execution failed: {message}")

    # Convert DataFrame to the expected format
    columns = list(result_df.columns)

    # Sanitize pandas NA variants (pd.NA, pd.NaT, np.nan) to Python None
    # so downstream JSON serialization does not choke on NAType.
    # Note: DataFrame.where() + .values.tolist() does NOT fully sanitize
    # nullable dtypes (Int64, string) or np.nan in float columns.
    # We must sanitize the final Python objects after .tolist().
    rows = result_df.values.tolist()
    for row in rows:
        for i, val in enumerate(row):
            if val is pd.NA or val is pd.NaT:
                row[i] = None
            elif isinstance(val, float) and math.isnan(val):
                row[i] = None

    # Create basic column metadata
    columns_meta = [
        {
            "name": col,
            "type": str(result_df[col].dtype),
            "nullable": True
        }
        for col in columns
    ]

    return columns, rows, columns_meta